=== Ojasvi Drapes Offers ===
Contributors: ojasvidrapes
Tags: woocommerce, bogo, offers, discount, india
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Buy 2 get 1 free, and offers like it, without a promo code.

== Description ==

Pick the products an offer covers. When a shopper has enough of them in the
cart, the cheapest ones come off the total on their own — no code to type, and
nothing for them to claim.

* Buy X get Y, at any percentage off. 100% is free; 50% makes the cheapest half
  price.
* Or quantity breaks — 2 for 10% off, 3 for 15% — counted per product, for the
  shopper buying a pair of the same thing.
* Choose products by hand, or by whole category, with an exclusion list.
* As many offers as you like — one for sarees, another for jewellery, each with
  its own products.
* The banner shows on every product it covers and at the top of the cart, with
  a live line telling the shopper how many more to add.
* Optional countdown to the end of the offer.
* The free line is struck through in the cart and marked, so the discount is
  never a mystery at checkout.

**Complete the look** is the second half of the plugin. On any product, pick
the pieces that go with it — the jhumkas for a saree, the bangles, a matching
blouse. They appear under the product with tick boxes, a running total and one
button that puts the whole look in the bag, and again in the cart as a
reminder under **Complete your look**. Give the pairing a percentage and the
matching pieces are discounted when they are bought with the product they were
chosen for.

Works with WooCommerce's High-Performance Order Storage. The discount is worked
out on the server, so it applies with JavaScript switched off.

== Installation ==

1. Upload the plugin and activate it.
2. Go to WooCommerce → Offers → Add offer.
3. Set buy 2, get 1, at 100% off. Pick your sarees, or the Sarees category.
4. Publish.

== Frequently Asked Questions ==

= Which item goes free? =

The cheapest of the qualifying items. With three sarees at ₹3,999, ₹2,999 and
₹1,200, the ₹1,200 one is free.

= What is the difference between the two kinds of offer? =

"Buy some, get some free" counts across everything the offer covers: any three
sarees, cheapest free. "The more you buy, the cheaper" counts per product: two
of the *same* saree, 10% off. Two different sarees do not earn a quantity
break — that is what the first kind is for.

= What happens with six? =

Two free, if "apply it again for every further set" is on. Turn it off and one
set per cart is the limit.

= Can I run one for jewellery as well? =

Yes — add a second offer and pick jewellery instead. They are counted
separately, so two sarees and two bangles is not three of anything.

= Does it need a coupon code? =

No. There is nothing for the shopper to enter.

= What is the difference between an offer and Complete the look? =

An offer counts items: any three sarees, cheapest free. Complete the look is a
pairing: this saree goes with those earrings, and here is a discount for taking
both. They can run together — a line already made free by an offer is never
discounted a second time by a pairing.

= Can the pairing work in both directions? =

Tick "Show this product on the matching products' pages too" and the saree
turns up beside the jewellery as well, without picking it again from that
side.

== Changelog ==

= 2.0.0 =
* Renamed from Sree Saanvika Offers to Ojasvi Drapes Offers. Existing offers
  and every Complete the look pairing are carried over the first time the
  plugin loads — nothing needs setting up again.

= 1.2.1 =
* The cart's matching pieces are "Complete your look", and become a compact
  list on a phone.

= 1.2.0 =
* Quantity breaks: buy 2 save 10%, 3 save 15%, counted per product.

= 1.1.0 =
* Complete the look: matching products per product, with an optional pairing
  discount.

= 1.0.0 =
* First release.
